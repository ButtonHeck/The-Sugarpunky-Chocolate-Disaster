var searchData=
[
  ['impl_792',['impl',['../class_settings_manager.html#a9dc1c119e42ab6dbcf34245dc6d61d20',1,'SettingsManager']]]
];
