var searchData=
[
  ['query_418',['Query',['../class_query.html',1,'']]]
];
