var searchData=
[
  ['landindirectbufferhasupdated_793',['landIndirectBufferHasUpdated',['../class_game.html#ac694c627329fce942e30a88c73c4079f',1,'Game']]],
  ['loading_5fdistance_5fchunks_794',['LOADING_DISTANCE_CHUNKS',['../class_plant_generator.html#aab32c64274b6f2d5f37d9e0d8507dc13',1,'PlantGenerator']]],
  ['loading_5fdistance_5fchunks_5flowpoly_795',['LOADING_DISTANCE_CHUNKS_LOWPOLY',['../class_plant_generator.html#a7c1f727b327796792bd4391a2749458d',1,'PlantGenerator']]],
  ['loading_5fdistance_5fchunks_5fshadow_796',['LOADING_DISTANCE_CHUNKS_SHADOW',['../class_plant_generator.html#a98e01456ae33bbf4328e8ccb1ebfc4f9',1,'PlantGenerator']]]
];
