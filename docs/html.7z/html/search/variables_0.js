var searchData=
[
  ['box_5factual_5fvertices_785',['BOX_ACTUAL_VERTICES',['../class_shadow_volume.html#adb7f645b9564a010e18076e058d7d40a',1,'ShadowVolume']]],
  ['box_5fexpected_5fvertices_786',['BOX_EXPECTED_VERTICES',['../class_shadow_volume.html#aaa840947b690612dc6c47ed4a45be92c',1,'ShadowVolume']]],
  ['box_5fmin_5fheight_787',['BOX_MIN_HEIGHT',['../class_shadow_volume.html#a85b3a76d170b8cc0b01ddf4534df176e',1,'ShadowVolume']]]
];
